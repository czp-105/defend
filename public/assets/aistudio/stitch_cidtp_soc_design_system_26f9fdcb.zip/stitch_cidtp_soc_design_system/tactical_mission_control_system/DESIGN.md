---
name: Tactical Mission Control System
colors:
  surface: '#101419'
  surface-dim: '#101419'
  surface-bright: '#36393f'
  surface-container-lowest: '#0a0e13'
  surface-container-low: '#181c21'
  surface-container: '#1c2025'
  surface-container-high: '#262a30'
  surface-container-highest: '#31353b'
  on-surface: '#e0e2ea'
  on-surface-variant: '#bdc8cd'
  inverse-surface: '#e0e2ea'
  inverse-on-surface: '#2d3136'
  outline: '#879397'
  outline-variant: '#3d494c'
  surface-tint: '#64d5f4'
  primary: '#64d5f4'
  on-primary: '#003641'
  primary-container: '#3fb6d4'
  on-primary-container: '#004452'
  inverse-primary: '#00677c'
  secondary: '#b9c8dc'
  on-secondary: '#233142'
  secondary-container: '#3a4859'
  on-secondary-container: '#a8b6cb'
  tertiary: '#b6c8dd'
  on-tertiary: '#203242'
  tertiary-container: '#98aabe'
  on-tertiary-container: '#2d3f50'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b0ecff'
  primary-fixed-dim: '#64d5f4'
  on-primary-fixed: '#001f27'
  on-primary-fixed-variant: '#004e5e'
  secondary-fixed: '#d5e4f9'
  secondary-fixed-dim: '#b9c8dc'
  on-secondary-fixed: '#0e1d2c'
  on-secondary-fixed-variant: '#3a4859'
  tertiary-fixed: '#d2e4fa'
  tertiary-fixed-dim: '#b6c8dd'
  on-tertiary-fixed: '#0a1d2d'
  on-tertiary-fixed-variant: '#37485a'
  background: '#101419'
  on-background: '#e0e2ea'
  surface-variant: '#31353b'
typography:
  headline-lg:
    fontFamily: Noto Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Noto Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Noto Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Noto Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-md:
    fontFamily: Noto Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Noto Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.03em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
  code-dense:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '400'
    lineHeight: 0.9375rem
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.5rem
  margin: 0.75rem
  space-xs: 0.125rem
  space-sm: 0.25rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style

This design system serves operators, blue teams, and defense analysts monitoring critical industrial telemetry, cyber-physical threats, and automated breach evaluations. The brand personality is precision-engineered, uncompromising, calm under operational duress, and austere. The aesthetic minimizes ocular exhaustion during prolonged multi-monitor shifts in low-ambient control rooms.

The visual style is **High-Density Technical Minimalist** combined with **Low-Glare Tactical Architecture**:
- Zero superficial decoration, drop shadows, or skeuomorphic embellishments.
- Depth is strictly achieved through engineered surface lamination and 1px precision hairline borders.
- Extreme data density with compact micro-layouts, ensuring situational awareness remains visible above the fold without page scrolling.
- Rigorous status signaling where color represents operational state exclusively, never cosmetic accentuation.

## Colors

The palette enforces absolute operational clarity under dark-room viewing conditions. Bright saturated surfaces are banned; high-contrast luminance is limited strictly to active telemetry alerts, focused cursors, and definitive verification states.

### Core Surface Tiers
- **Canvas (`#0A0E13`)**: The master background substrate across screens and viewports.
- **Panel Surface (`#111821`)**: Base container tier for structural monitors, side docks, and operational logs.
- **Floating Surface (`#16202B`)**: Contextual overlays, modal inspector trays, drop-downs, and hovering metric cards.
- **Table Header (`#0E151D`)**: Grounded neutral base for tabular columnar headers and segment navigators.

### Linework & Structural Delimiters
- **Hairline (`#223040`)**: Structural border stroke on active or distinct panels.
- **Divider (`#1A2431`)**: Interior dividers, data-row split lines, and structural shelf delimiters.

### Typography Levels
- **Primary Text (`#DDE7F2`)**: High-legibility target for active readings, system state, and essential metrics.
- **Secondary Text (`#8FA1B5`)**: Metadata, labels, timestamps, and column titles.
- **Disabled / Inert Text (`#5A6A7D`)**: Deactivated switches, null payloads, and historical breadcrumbs.

### Tactical Action & Interactive Accents
- **Interactive Accent (`#3FB6D4`)**: Reserved exclusively for active selection rings, active tabs, telemetry scrubbers, and primary operator command actions.

### State Semantics: Test Conclusion vs. Expected Action
The system strictly separates **Empirical Test Conclusions** (what was detected) from **Operator Expected Actions** (what must be executed):

- **Empirical Test Conclusions (Status Detection):**
  - *Confirmed Breach / Critical Deviation*: `#F43F5E` (High-alert Crimson)
  - *Anomalous / Warning Indicator*: `#F59E0B` (Amber Warning)
  - *Nominal Baseline / Verified Defended*: `#10B981` (Verification Emerald)
  - *Inconclusive / Telemetry Gap*: `#64748B` (Muted Slate)

- **Expected Operator Actions (Mitigation Directives):**
  - *Immediate Isolation Mandatory*: `#E11D48` background tint with solid border
  - *Investigation Required*: `#D97706` background tint
  - *Acknowledge / Clear*: `#0284C7` (Directive Cobalt Blue — distinct from empirical green to prevent false confirmation)
  - *Bypass / Manual Override*: `#8B5CF6` (Procedural Violet)

## Typography

Typography balances rapid scanning with dense international glyph support. 

- **Primary UI & Headings**: Handled by **Noto Sans** (including Noto Sans SC / Source Han Sans for regional deployments), selected for its neutral geometric legibility at small sizes and extensive CJK glyph support.
- **Technical Readouts, Tables, Telemetry, & Timestamps**: Handled by **JetBrains Mono**. All numerals must strictly employ `font-variant-numeric: tabular-nums` (monospaced numbers) to prevent horizontal jitter during rapid live-streamed metric changes.
- **Hierarchy Rules**:
  - Uppercase styling with expanded tracking (`0.03em` to `0.04em`) is mandatory for telemetry field names, table headers, and operational status flags.
  - Body text uses standard sentence casing with compact line-heights calibrated to maximize the number of visible lines per monitor without line collision.

## Layout & Spacing

The layout is built for high-density, multi-panel mission control walls and desktop workstations (1080p, 1440p, 4K). 

- **Grid Philosophy**: Fluid 24-column modular workbench grid with a base increment of 4px. Columns stretch across target viewports, snapping to fixed tool trays, side rails, and multi-stream splitters.
- **Gutter & Margins**: Minimalist gutters (`0.5rem` / 8px) ensure maximum screen real estate is dedicated to actionable information, surrounded by a constant outer canvas bezel (`0.75rem` / 12px).
- **Internal Density**: Micro spacing (`space-xs` = 2px, `space-sm` = 4px, `space-md` = 8px) controls cell interior margins and pill paddings to ensure that complex matrices display maximum content density.
- **Adaptive Breakpoints**:
  - *Large Operations Wall / Quad-HD (≥1920px)*: Full 24-column layout displaying 3-to-4 simultaneous data views (Topology, Event Bus, Raw Hex, Action Rail).
  - *Standard Console (1280px - 1919px)*: 12-column condensed layout; secondary inspection logs collapse into fly-out side sheets.
  - *Tactical Field Laptop (<1280px)*: Unified stacked canvas with persistent horizontal status bar and tabbed module switching.

## Elevation & Depth

Shadows and blurs are prohibited to eliminate visual softness and display latency. Elevation is communicated strictly through tonal lamination and crisp, single-pixel perimeter boundaries.

- **Level 0 (Base Substrate)**: Canvas `#0A0E13`. Flat, non-interactive.
- **Level 1 (Structural Modules)**: Panel Surface `#111821` encased in a 1px solid Hairline (`#223040`). Used for log tables, node graphs, and telemetry cards.
- **Level 2 (Active Inspection & Floating Elements)**: Floating Surface `#16202B` with a 1px solid Hairline (`#223040`) border. Used for context menus, modal diagnostics, and inspector panels.
- **Focus & Selection**: When a panel, row, or component is actively targeted, the 1px perimeter border transitions from Hairline (`#223040`) directly to Interactive Accent (`#3FB6D4`). No exterior drop shadows or ambient glows are permitted.

## Shapes

The design system enforces a strict 4px radius (`roundedness: 1`) across all interactive, container, and input elements.

- **Panels, Windows, and Modals**: Fixed 4px corner radius.
- **Action Buttons, Inputs, Chips, and Badges**: Fixed 4px corner radius.
- **Zero Radius Elements**: Embedded sub-table cells, nested segmented bars, vertical line dividers, and raw terminal log windows use 0px radius to maintain seamless grid lines.
- No pill shapes (`rounded-full`) or circular buttons are permitted; geometric discipline must remain uniform across all controls.

## Components

### Buttons
- **Primary Operational Action**: Background `#3FB6D4`, text `#0A0E13` (bold weight), 1px border `#3FB6D4`. Hover transitions to `#52C5E2`.
- **Secondary / Panel Action**: Background `#16202B`, text `#DDE7F2`, 1px border `#223040`. Hover shifts background to `#1E2C3A`.
- **Critical Abort / Defensive Action**: Solid or tinted background derived from expected action semantics (`#E11D48`), white text `#FFFFFF`, 1px border `#F43F5E`.
- **Sizing**: Compact (24px height, padding 0 8px) and Standard (32px height, padding 0 12px). Labels set in JetBrains Mono.

### Chips & Semantic Badges
- **Structure**: Height 20px, font `label-sm` (JetBrains Mono uppercase), 4px border radius.
- **Empirical Status Badge**: 1px border matching the status color with an interior 15% opacity tint of the same color (e.g., `#F43F5E` outline + `#F43F5E26` background). Text matches the bright semantic hue.
- **Action Directive Badge**: Solid background with inverse high-contrast text, accompanied by an explicit directive icon (e.g., `[!] ISOLATE HOST`).

### Data Tables & Log Grids
- **Header**: Background `#0E151D`, text `#8FA1B5`, height 28px, 1px bottom border `#223040`. Text is uppercase `label-md`.
- **Rows**: Alternating or flat `#111821` with 1px bottom divider `#1A2431`. Row height is fixed at 28px (ultra-dense) or 36px (standard).
- **Numerics / Timestamps**: Strictly right-aligned or columnar fixed-width, rendered in JetBrains Mono tabular figures.
- **Selected Row**: Background `#16202B`, left border accentuated with a 2px `#3FB6D4` vertical indicator strip.

### Input Fields & Selectors
- **Base State**: Background `#0A0E13`, 1px border `#223040`, text `#DDE7F2`, height 28px or 32px, 4px border radius. Placeholder text `#5A6A7D`.
- **Focus State**: Border `#3FB6D4`, no outer halo.
- **Inline Key-Value Inputs**: Monospaced value entry with fixed width label prefix.

### Checkboxes & Toggle Switches
- **Checkbox**: 14x14px square, 2px border radius, 1px border `#223040`, background `#0A0E13`. Checked state displays `#3FB6D4` fill with `#0A0E13` check glyph.
- **Toggles**: 28x16px rectangular track, 12x12px square toggle thumb with 2px radius (no circular knobs). Unchecked track `#1A2431`, checked track `#3FB6D4`.

### Cards & Telemetry Pods
- **Structure**: Background `#111821`, 1px perimeter border `#223040`, 4px radius. 
- **Header Bar**: Height 28px, border-bottom 1px `#1A2431`, title in `label-md` uppercase `#8FA1B5` paired with a right-aligned live pulse or stream frequency indicator.
- **Internal Margins**: 8px padding (`space-md`).